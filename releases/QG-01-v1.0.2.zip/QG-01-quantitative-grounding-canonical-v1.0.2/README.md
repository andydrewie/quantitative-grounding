# QG-01 - Quantitative Grounding Skill

**Canonical version:** 1.0.2  
**Status:** Source of truth  
**Supersedes:** QG-01 v1.0.0 and v1.0.1

QG-01 is a portable, model-agnostic skill for adding decision-useful quantitative grounding without false precision.

## Source-of-truth order

1. `SKILL.md` - normative behavioral specification.
2. `SYSTEM_PROMPT.txt` - compact deployment prompt.
3. `EVALS.md` - behavioral tests and pass/fail criteria.
4. `CANONICAL_SUMMARY.md` - human-readable explanation reproduced from the original formalization.
5. `CHANGELOG.md` - version history and clarification of the mojibake issue.

If two files appear to conflict, `SKILL.md` controls.

## What changed from the original package

The original v1.0.0 skill was functionally valid. Version 1.0.2 makes only portability and wording corrections:

- fixes the missing space in the frontmatter description;
- replaces `best/top questions` with the concise category `superlative requests`;
- uses ASCII-safe punctuation to reduce mojibake risk in mobile and plain-text previews;
- declares one canonical package so earlier copies no longer create ambiguity.

The quantitative-grounding behavior itself is unchanged.

## Recommended deployment

### Persistent assistant behavior

Paste `SYSTEM_PROMPT.txt` into the model's system prompt or custom instructions.

### Agent or Codex skill

Place `SKILL.md` in the project's skills directory and instruct the agent to activate `QG-01` for substantive analytical questions.

### On-demand use

- `Run QG-01 on this question.`
- `Use QG-01/Standard.`
- `Use QG-01/Deep and include sensitivity analysis.`

## Design philosophy

The skill does not maximize the number of statistics. It identifies the smallest set of defensible numbers that materially improves understanding, comparison, and action.
