#!/usr/bin/env python3
"""Validate the canonical QG-01 package."""

from __future__ import annotations

import sys
from pathlib import Path

REQUIRED = {
    "SKILL.md",
    "SYSTEM_PROMPT.txt",
    "README.md",
    "EVALS.md",
    "CANONICAL_SUMMARY.md",
    "CHANGELOG.md",
}
MOJIBAKE_MARKERS = ("\u00e2", "\u00c3", "\ufffd")


def main() -> int:
    root = Path(__file__).resolve().parent
    errors: list[str] = []
    files = {p.name for p in root.iterdir() if p.is_file()}
    missing = sorted(REQUIRED - files)
    if missing:
        errors.append("Missing required files: " + ", ".join(missing))

    for path in sorted(root.iterdir()):
        if not path.is_file() or path.name in {Path(__file__).name, "SHA256SUMS.txt"}:
            continue
        raw = path.read_bytes()
        if raw.startswith(b"\xef\xbb\xbf"):
            errors.append(f"{path.name}: UTF-8 BOM is not allowed")
        try:
            text = raw.decode("utf-8")
        except UnicodeDecodeError as exc:
            errors.append(f"{path.name}: invalid UTF-8 ({exc})")
            continue
        for marker in MOJIBAKE_MARKERS:
            if marker in text:
                errors.append(f"{path.name}: contains mojibake marker {marker!r}")
        non_ascii = sorted({ch for ch in text if ord(ch) > 127})
        if non_ascii:
            codes = " ".join(f"U+{ord(ch):04X}" for ch in non_ascii)
            errors.append(f"{path.name}: contains non-ASCII characters ({codes})")

    skill = root / "SKILL.md"
    if skill.exists():
        text = skill.read_text(encoding="utf-8")
        if "version: 1.0.2" not in text.split("---", 2)[1]:
            errors.append("SKILL.md: canonical version is not 1.0.2")
        if "- rankings, comparisons, or superlative requests;" not in text:
            errors.append("SKILL.md: canonical trigger wording is missing")

    if errors:
        print("QG-01 canonical package validation FAILED")
        for error in errors:
            print(f"- {error}")
        return 1

    print("QG-01 canonical package validation PASSED")
    print("- Version: 1.0.2")
    print("- Required files present")
    print("- Valid UTF-8 without BOM")
    print("- ASCII-safe punctuation")
    print("- Mojibake markers absent")
    return 0


if __name__ == "__main__":
    sys.exit(main())
